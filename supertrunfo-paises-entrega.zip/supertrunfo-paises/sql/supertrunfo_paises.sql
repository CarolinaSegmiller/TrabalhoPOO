CREATE DATABASE IF NOT EXISTS supertrunfo_paises;
USE supertrunfo_paises;

CREATE TABLE IF NOT EXISTS pais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    capital VARCHAR(100) NOT NULL,
    populacao BIGINT NOT NULL,
    area DOUBLE NOT NULL,
    pib DOUBLE NOT NULL,
    pontos_turisticos INT NOT NULL
);

INSERT INTO pais (nome, capital, populacao, area, pib, pontos_turisticos) VALUES
('Brasil', 'Brasília', 203062512, 8515767.0, 2.17, 25),
('Estados Unidos', 'Washington, D.C.', 340110988, 9833517.0, 27.72, 30),
('Japão', 'Tóquio', 123790000, 377975.0, 4.21, 20),
('França', 'Paris', 68373433, 551695.0, 3.05, 18),
('Canadá', 'Ottawa', 40126965, 9984670.0, 2.14, 22);
