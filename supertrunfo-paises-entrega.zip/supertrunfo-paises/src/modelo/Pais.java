package modelo;

public class Pais {
    private Integer id;
    private String nome;
    private String capital;
    private long populacao;
    private double area;
    private double pib;
    private int pontosTuristicos;

    public Pais() {
    }

    public Pais(String nome, String capital, long populacao, double area, double pib, int pontosTuristicos) {
        this.nome = nome;
        this.capital = capital;
        this.populacao = populacao;
        this.area = area;
        this.pib = pib;
        this.pontosTuristicos = pontosTuristicos;
    }

    public Pais(Integer id, String nome, String capital, long populacao, double area, double pib, int pontosTuristicos) {
        this.id = id;
        this.nome = nome;
        this.capital = capital;
        this.populacao = populacao;
        this.area = area;
        this.pib = pib;
        this.pontosTuristicos = pontosTuristicos;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public long getPopulacao() {
        return populacao;
    }

    public void setPopulacao(long populacao) {
        this.populacao = populacao;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getPib() {
        return pib;
    }

    public void setPib(double pib) {
        this.pib = pib;
    }

    public int getPontosTuristicos() {
        return pontosTuristicos;
    }

    public void setPontosTuristicos(int pontosTuristicos) {
        this.pontosTuristicos = pontosTuristicos;
    }

    @Override
    public String toString() {
        return String.format(
                "ID: %d | País: %s | Capital: %s | População: %d | Área: %.2f km² | PIB: %.2f tri US$ | Pontos Turísticos: %d",
                id, nome, capital, populacao, area, pib, pontosTuristicos);
    }
}
